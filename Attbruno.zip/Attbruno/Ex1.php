<?php



class Funcionario {
    public $nome;
    public $salario;

    public function __construct($nome, $salario) {
        $this->nome = $nome;
        $this->salario = $salario;
    }

    public function calcularBonus() {
        return $this->salario * 0.10;
    }
}


class Gerente extends Funcionario {
}


    class Desenvolvedor extends Funcionario {
}




        $gerente = new Gerente("João", 20000);
$desenvolvedor = new Desenvolvedor("Maria", 8000);

echo "Nome: " . $gerente->nome . "\n";
echo "Cargo: Gerente\n";

echo "Bônus: " . $gerente->calcularBonus() . "\n\n";

echo "Nome: " . $desenvolvedor->nome . "\n";
echo "Cargo: Desenvolvedor\n";
echo "Bônus: " . $desenvolvedor->calcularBonus() . "\n";

?>