<?php

class Funcionario {
    public $nome;
    public $salario;
    public $cargo;

    public function __construct($nome, $salario, $cargo) {
        $this->nome = $nome;
        $this->salario = $salario;
        $this->cargo = $cargo;
    }

    public function calcularBonus() {
        return $this->salario * 0.10;
    }

    public function exibirDados() {
        echo "Funcionario: " . $this->nome . " (" . $this->cargo . ")\n";
        echo "Bônus: " . $this->calcularBonus() . "\n\n";
    }
}

class Gerente extends Funcionario {
    public function calcularBonus() {
        return $this->salario * 0.20;
    }
}

class Desenvolvedor extends Funcionario {
    public function calcularBonus() {
        return $this->salario * 0.15;
    }
}

$listaDefuncionarios = array(
    new Gerente("João", 10000, "Gerente"),
    new Desenvolvedor("Maria", 8000, "Desenvolvedor"),
    new Desenvolvedor("Pedro", 5000, "Desenvolvedor")
);

foreach ($listaDefuncionarios as $func) {
    $func->exibirDados();
}

?>