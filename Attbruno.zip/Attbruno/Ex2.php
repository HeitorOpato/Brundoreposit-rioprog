<?php

class Funcionario {
    public $nome;
    public $salario;

    public function __construct($nome, $salario) {
        $this->nome = $nome;
        $this->salario = $salario;
    }

    public function calcularBonus() {
        return $this->salario * 0.10;
    }

    public function exibirDados($cargo) {
        echo "Nome: " . $this->nome . "\n";
        echo "Cargo: " . $cargo . "\n";
        echo "Bônus: " . $this->calcularBonus() . "\n\n";
    }
}

class Gerente extends Funcionario {
    public function calcularBonus() {
        return $this->salario * 0.20;
    }
}

class Desenvolvedor extends Funcionario {
    public function calcularBonus() {
        return $this->salario * 0.15;
    }
}

$gerente = new Gerente("João", 10000);
$desenvolvedor = new Desenvolvedor("Maria", 10000);

$gerente->exibirDados("Gerente");
$desenvolvedor->exibirDados("Desenvolvedor");

?>